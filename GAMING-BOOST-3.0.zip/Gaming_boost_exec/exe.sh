#!/system/bin/sh
ver=3.0
dev=@HenVx
epep=com.dts.freefireth
epepmax=com.dts.freefiremax
pubg=com.tencent.ig
mlbb=com.mobile.legends
hwag=com.mobilelegends.hwag
echo ""
echo "
█▀▀ ▄▀█ █▀▄▀█ █ █▄░█ █▀▀   █▄▄ █▀█ █▀█ █▀ ▀█▀
█▄█ █▀█ █░▀░█ █ █░▀█ █▄█   █▄█ █▄█ █▄█ ▄█ ░█░"
echo "[ 𝗜𝗻𝗳𝗼𝗿𝗺𝗮𝘁𝗶𝗼𝗻 𝗔𝗯𝗼𝘂𝘁 ] "
echo "Developer : ${dev} "
echo "Version : ${ver} "
echo ""
echo ""
sleep 3
echo "[ 𝗗𝗲𝘃𝗶𝗰𝗲 𝗜𝗻𝗳𝗼 ]"
echo ""
sleep 0.5
echo "DEVICE=$(getprop ro.product.model) "
sleep 1
echo "BRAND=$(getprop ro.product.system.brand) "
sleep 1
echo "MODEL=$(getprop ro.build.product) "
sleep 1
echo "KERNEL=$(uname -r) "
sleep 1
echo "GPU INFO=$(getprop ro.hardware.egl) "
sleep 1
echo "CPU INFO=$(getprop ro.hardware) "
echo ""
sleep 2
echo "[ 𝗦𝘂𝗽𝗽𝗼𝗿𝘁 𝗠𝗲 ]"
sleep 0.5
echo " Resource: https://t.me/HenVx1  "
sleep 0.5
echo " Discussion: https://t.me/HenVx10 "
sleep 2
echo ""
sleep 5
echo "[■□□□□□□□□□]  "
sleep 2
echo "[■■□□□□□□□□]  "
sleep 2
echo "[■■■□□□□□□□]  "
sleep 2
echo "[■■■■□□□□□□]  "
sleep 2
echo "[■■■■■□□□□□]  "
sleep 2
echo "[■■■■■■□□□□]  "
sleep 2
echo "[■■■■■■■□□□]  "
sleep 2
echo "[■■■■■■■■□□]  "
sleep 2
echo "[■■■■■■■■■□] "
sleep 8
echo "[■■■■■■■■■■] "
sleep 0.5
echo ""
sleep 2
(
settings put global device_idle_constants light_after_inactive_to 2592000000
am kill-all
)> /dev/null 2>&1
(
cmd package bg-dexopt-job
cmd shortcut reset-all-throttling
cmd game mode performance ${epep}
cmd game mode performance ${pubg}
cmd game mode performance ${mlbb}
cmd game mode performance ${hwag}
cmd game mode performance ${epepmax}
appops set ${epep} RUN_IN_BACKGROUND allow
appops set ${pubg} RUN_IN_BACKGROUND allow
appops set ${mlbb} RUN_IN_BACKGROUND allow
appops set ${hwag} RUN_IN_BACKGROUND allow
appops set ${epepmax} RUN_IN_BACKGROUND allow
cmd package compile -m everything-profile -f ${epep}
cmd package compile -m everything-profile -f ${pubg}
cmd package compile -m everything-profile -f ${mlbb}
cmd package compile -m everything-profile -f ${epepmax}
cmd package compile -m everything-profile -f ${hwag}
cmd package compile -m speed --secondary-dex -f ${epep}
cmd package compile -m speed --secondary-dex -f ${pubg}
cmd package compile -m speed --secondary-dex -f ${mlbb}
cmd package compile -m speed --secondary-dex -f ${epepmax}
cmd package compile -m speed --secondary-dex -f ${hwag}
cmd package compile -m speed --check-prof false -f ${epep}
cmd package compile -m speed --check-prof false -f ${pubg}
cmd package compile -m speed --check-prof false -f ${mlbb}
cmd package compile -m speed --check-prof false -f ${epepmax}
cmd package compile -m speed --check-prof false -f ${hwag}
cmd appops set com.google.android.gms RUN_IN_BACKGROUND ignore
cmd appops set com.google.android.gms RUN_ANY_IN_BACKGROUND ignore
cmd appops set com.google.android.gms START_FOREGROUND ignore
cmd appops set com.google.android.gms INSTANT_APP_START_FOREGROUND ignore
cmd appops set com.google.android.ims RUN_IN_BACKGROUND ignore
cmd appops set com.google.android.ims RUN_ANY_IN_BACKGROUND ignore
cmd appops set com.google.android.ims START_FOREGROUND ignore
cmd appops set com.google.android.ims INSTANT_APP_START_FOREGROUND ignore
cmd netpolicy set restrict-background false
am broadcast -a android.intent.action.ACTION_OPTIMIZE_DEVICE
am broadcast -a android.intent.action.SET_SCREEN_REFRESH_RATE -e refreshRate 120 -e fpsMode fixed
rm -f /storage/emulated/0/Pictures/.thumbnails/*
rm -f /storage/emulated/0/Movies/.thumbnails/*
rm -f /data/local/traces/*
am force-stop com.google.android.ims
am force-stop com.google.android.gms
cmd power set-adaptive-power-saver-enabled false
cmd power set-mode 0
)> /dev/null 2>&1
(
am force-stop com.android.providers.media
am force-stop com.android.providers.media.module
am force-stop com.google.android.gms/.kids.account.activities.RegisterProfileOwnerActivity
am force-stop com.google.android.gms/.kids.account.receiver.ProfileOwnerReceiver
am force-stop com.google.android.gms/.kids.chimera.AccountChangeReceiverProxy
am force-stop com.google.android.gms/.kids.chimera.AccountSetupCompletedReceiverProxy
am force-stop com.google.android.gms/.kids.chimera.AccountSetupServiceProxy
am force-stop com.google.android.gms/.kids.chimera.DeviceTimeAndDateChangeReceiverProxy
am force-stop com.google.android.gms/.kids.chimera.InternalEventReceiverLmpProxy
am force-stop com.google.android.gms/.kids.chimera.InternalEventReceiverProxy
am force-stop com.google.android.gms/.kids.chimera.KidsApiServiceProxy
am force-stop com.google.android.gms/.kids.chimera.KidsDataProviderProxy
am force-stop com.google.android.gms/.kids.chimera.KidsDataSyncServiceProxy
am force-stop com.google.android.gms/.kids.chimera.KidsServiceProxy
am force-stop com.google.android.gms/.kids.chimera.LocationModeChangedReceiverProxy
am force-stop com.google.android.gms/.kids.chimera.LongRunningServiceProxy
am force-stop com.google.android.gms/.kids.chimera.PackageChangedReceiverProxy
am force-stop com.google.android.gms/.kids.chimera.SlowOperationServiceProxy
am force-stop com.google.android.gms/.kids.chimera.SystemEventReceiverProxy
am force-stop com.google.android.gms/.kids.chimera.TimeoutsSystemAlertServiceProxy
am force-stop com.google.android.gms/.kids.common.sync.ManualSyncReceiver
am force-stop com.google.android.gms/.kids.creation.activities.FamilyCreationActivity
am force-stop com.google.android.gms/.kids.device.RingService
am force-stop com.google.android.gms/.location.copresence.GcmBroadcastReceiver
am force-stop com.google.android.gms/.location.reporting.service.GcmBroadcastReceiver
am force-stop com.google.android.gms/.measurement.PackageMeasurementTaskService
am force-stop com.google.android.gms/.measurement.service.MeasurementBrokerService
am force-stop com.google.android.gms/.nearby.bootstrap.service.NearbyBootstrapService
am force-stop com.google.android.gms/.nearby.connection.service.NearbyConnectionsAndroidService
am force-stop com.google.android.gms/.nearby.connection.service.NearbyConnectionsAsyncService
am force-stop com.google.android.gms/.nearby.messages.NearbyMessagesBroadcastReceiver
am force-stop com.google.android.gms/.nearby.messages.service.NearbyMessagesService
am force-stop com.google.android.gms/.nearby.messages.settings.NearbyMessagesAppOptInActivity
am force-stop com.google.android.gms/.nearby.settings.NearbyAccessActivity
am force-stop com.google.android.gms/.nearby.settings.NearbyAppUninstallReceiver
am force-stop com.google.android.gms/.nearby.settings.NearbySettingsActivity
am force-stop com.google.android.gms/.nearby.sharing.service.NearbySharingService
am force-stop com.google.android.gms/.perfprofile.uploader.PerfProfileCollectorService
am force-stop com.google.android.gms/.perfprofile.uploader.RequestPerfProfileCollectionService
am force-stop com.google.android.gms/.phenotype.receiver.PhenotypeBroadcastReceiver
am force-stop com.google.android.gms/.phenotype.service.PhenotypeCommitService
am force-stop com.google.android.gms/.phenotype.service.PhenotypeIntentService
am force-stop com.google.android.gms/.phenotype.service.sync.PhenotypeConfigurator
am force-stop com.google.android.gms/.phenotype.service.util.PhenotypeDebugService
am force-stop com.google.android.gms/.photos.InitializePhotosIntentReceiver
am force-stop com.google.android.gms/.photos.autobackup.AutoBackupWorkService
am force-stop com.google.android.gms/.photos.autobackup.service.AutoBackupService
am force-stop com.google.android.gms/.photos.autobackup.ui.AutoBackupSettingsActivity
am force-stop com.google.android.gms/.photos.autobackup.ui.AutoBackupSettingsRedirectActivity
am force-stop com.google.android.gms/.photos.autobackup.ui.LocalFoldersBackupSettings
am force-stop com.google.android.gms/.photos.autobackup.ui.promo.AutoBackupPromoActivity
am force-stop com.google.android.gms/.plus.activity.AccountSignUpActivity
am force-stop com.google.android.gms/.plus.apps.ListAppsActivity
am force-stop com.google.android.gms/.plus.apps.ManageAppActivity
am force-stop com.google.android.gms/.plus.apps.ManageDeviceActivity
am force-stop com.google.android.gms/.plus.apps.ManageMomentActivity
am force-stop com.google.android.gms/.plus.audience.AclSelectionActivity
am force-stop com.google.android.gms/.plus.audience.AudienceSearchActivity
am force-stop com.google.android.gms/.plus.audience.CircleCreationActivity
)> /dev/null 2>&1
(
cmd thermalservice override-status 0
cmd power set-fixed-performance-mode-enabled true
settings put global policy_control immersive.navigation com.android.systemui
settings put global policy_control immersive.full 1
settings put global device_idle_constants light_after_inactive_to 2592000000
)> /dev/null 2>&1
{
for app in $(cmd package list packages -3 | cut -f 2 -d ":"); do
if [[ ! "$app" == "me.piebridge.brevent" ]]; then
cmd activity force-stop "$app"
cmd activity kill "$app"
fi
done
} > /dev/null 2>&1
{
setprop debug.gralloc.gfx_ubwc_disable false
setprop debug.mdpcomp.mixedmode.disable false
setprop debug.mdpcomp.maxpermixer -1
setprop debug.stagefright.c2inputsurface -1
setprop debug.stagefright.ccodec 4
setprop debug.stagefright.omx_default_rank 512
setprop debug.sf.hwc.min.duration 0
setprop debug.scenegraph.batching_performance 1
setprop debug.sf.disable_client_composition_cache 1
setprop debug.ae.plineinfo 0
setprop debug.thread_raw.log 0
setprop debug.pdflow.disable 1
setprop debug.pd_verify_flow.run 1
setprop debug.pd_verify_flow.enable 1
setprop log.tag.event OFF
setprop log.tag.ALL S
setprop log.tag.APM_AudioPolicyManager S
setprop log.tag.BatchInternal S
setprop debug.vendor.uxProgram FALSE
setprop debug.hwui.use_gl_trace 0
setprop debug.threadedOpt 1
setprop debug.hwui.disable_vsync true
setprop debug.performance.tuning 1

} > /dev/null 2>&1
echo ""
echo " Done. "
echo