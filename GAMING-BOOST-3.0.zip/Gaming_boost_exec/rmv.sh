#ladb/android/system/modules/hen/id/remove

echo " Remove Gaming Boost "
sleep 2
echo ""
echo " Succes "
sleep 2
(
cmd thermalservice reset 
settings delete global device_idle_constants
settings put global policy_control immersive.navigation null
settings put global policy_control immersive.full null
)> /dev/null 2>&1